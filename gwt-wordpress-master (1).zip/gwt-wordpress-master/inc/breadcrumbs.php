<?php
/**
 * @file
 * breadcrumb file template
 */
// TODO: add a widget that can replace the default breadcrumb
?>

<nav id="breadcrumbs" class="anchor" aria-label="You are here:" role="navigation">
	<div class="row">
		<div class="large-12 columns">
    		<?php gwt_wp_breadcrumb(); ?>
		</div>
	</div>
</nav>